
![ETL_DL_DEPARTAMENTOS](https://github.com/user-attachments/assets/39b2439e-f85b-471f-b262-b49075c7dd4a)
